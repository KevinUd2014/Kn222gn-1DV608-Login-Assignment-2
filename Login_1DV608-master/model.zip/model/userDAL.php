<?php

	class userDAL{
		private $conn;

		public function createSqlConnection(){
			$SQLservername = "localhost";
			$SQLusername = "Register";
			$SQLpassword = "Register123";
			//$SQLDatabase = "Assignment4";
			$SQLDatabase = "Register";

			// Create connection
			$this->conn = mysqli_connect($SQLservername, $SQLusername,$SQLpassword, $SQLDatabase);

			if (!$this->conn) {

			    die("Could not connect: " . mysql_error());

			}
			//echo "Connected successfully";
			return $this->conn;

			
		}
		public function closeSqlConnection(){
			mysqli_close($this->conn);
		}
	}