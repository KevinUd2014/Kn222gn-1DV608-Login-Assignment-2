<?php

	class userCredentials{
	
	}